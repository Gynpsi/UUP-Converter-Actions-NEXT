@echo off
cd /d "%~dp0"
if NOT "%cd%"=="%cd: =%" (
    echo Current directory contains spaces in its path.
    echo Please move or rename the directory to one not containing spaces.
    echo.
    pause
    goto :EOF
)

if "[%1]" == "[49127c4b-02dc-482e-ac4f-ec4d659b7547]" goto :START_PROCESS
REG QUERY HKU\S-1-5-19\Environment >NUL 2>&1 && goto :START_PROCESS
set command="""%~f0""" 49127c4b-02dc-482e-ac4f-ec4d659b7547
SETLOCAL ENABLEDELAYEDEXPANSION
set "command=!command:'=''!"
powershell -NoProfile Start-Process -FilePath '%COMSPEC%' ^
    -ArgumentList '/c """!command!"""' -Verb RunAs 2>NUL
IF %ERRORLEVEL% GTR 0 (
    echo =====================================================
    echo This script needs to be executed as an administrator.
    echo =====================================================
    echo.
    pause
)
SETLOCAL DISABLEDELAYEDEXPANSION
goto :EOF

:START_PROCESS
title 20349.5499_amd64_zh-cn_multi_b6b6d2f5 download
set "aria2=files\aria2c.exe"
set "a7z=files\7zr.exe"
set "uupConv=files\uup-converter-wimlib.7z"
set "aria2Script1=files\aria2_script_set1.%random%.txt"
set "aria2Script2=files\aria2_script_set2.%random%.txt"
set "destDir=UUPs"

powershell -NoProfile -ExecutionPolicy Unrestricted .\files\get_aria2.ps1 || (pause & exit /b 1)
echo.

echo Downloading the UUP converter...
"%aria2%" --no-conf --async-dns=false --console-log-level=warn --log-level=info --log="aria2_download.log" -x16 -s16 -j2 -c -R -d"files" -i"files\converter_windows"
if %ERRORLEVEL% GTR 0 call :DOWNLOAD_CONVERTER_ERROR & exit /b 1

echo.
if NOT EXIST ConvertConfig.ini goto :NO_FILE_ERROR
if NOT EXIST CustomAppsList.txt goto :NO_FILE_ERROR
if NOT EXIST %a7z% goto :NO_FILE_ERROR
if NOT EXIST %uupConv% goto :NO_FILE_ERROR

echo Extracting UUP converter...
"%a7z%" -x!ConvertConfig.ini -x!CustomAppsList.txt -y x "%uupConv%" >NUL
echo.

REM ---------- Set 1: serverdatacenter / serverstandard ----------
:DOWNLOAD_UUPS
echo Retrieving aria2 script for the UUP set...
"%aria2%" --no-conf --async-dns=false --console-log-level=warn --log-level=info --log="aria2_download.log" -o"%aria2Script1%" --allow-overwrite=true --auto-file-renaming=false "https://uupdump.net/get.php?id=b6b6d2f5-e98b-4f73-927f-19909ec504ee&pack=zh-cn&edition=serverdatacenter%%3Bserverdatacentercore%%3Bserverstandard%%3Bserverstandardcore&aria2=2"
if %ERRORLEVEL% GTR 0 goto :RETRY_SET1

for /F "tokens=2 delims=:" %%i in ('findstr #UUPDUMP_ERROR: "%aria2Script1%"') do set DETECTED_ERROR=%%i
if NOT [%DETECTED_ERROR%] == [] (
    echo Unable to retrieve data from Windows Update servers. Reason: %DETECTED_ERROR%
    echo If this problem persists, most likely the set you are attempting to download was removed from Windows Update servers.
    echo.
    pause
    goto :EOF
)

echo Downloading the UUP set...
"%aria2%" --no-conf --async-dns=false --console-log-level=warn --log-level=info --log="aria2_download.log" -x16 -s16 -j5 -c -R -d"%destDir%" -i"%aria2Script1%"
if %ERRORLEVEL% GTR 0 goto :RETRY_SET1
goto :DOWNLOAD_UUPS2

:RETRY_SET1
echo Download failed, retrying set 1 in 30 seconds...
timeout /t 30 /nobreak >NUL
goto :DOWNLOAD_UUPS

REM ---------- Set 2: serverazurestackhcicor ----------
:DOWNLOAD_UUPS2
echo Retrieving aria2 script for the UUP set2...
"%aria2%" --no-conf --async-dns=false --console-log-level=warn --log-level=info --log="aria2_download.log" -o"%aria2Script2%" --allow-overwrite=true --auto-file-renaming=false "https://uupdump.net/get.php?id=890d35b3-a7a4-49e4-8da4-bed4b047a9b1&pack=zh-cn&edition=serverazurestackhcicor&aria2=2"
if %ERRORLEVEL% GTR 0 goto :RETRY_SET2

for /F "tokens=2 delims=:" %%i in ('findstr #UUPDUMP_ERROR: "%aria2Script2%"') do set DETECTED_ERROR=%%i
if NOT [%DETECTED_ERROR%] == [] (
    echo Unable to retrieve data from Windows Update servers. Reason: %DETECTED_ERROR%
    echo If this problem persists, most likely the set you are attempting to download was removed from Windows Update servers.
    echo.
    pause
    goto :EOF
)

echo Downloading the UUP set2...
"%aria2%" --no-conf --async-dns=false --console-log-level=warn --log-level=info --log="aria2_download.log" -x16 -s16 -j5 -c -R -d"%destDir%" -i"%aria2Script2%"
if %ERRORLEVEL% GTR 0 goto :RETRY_SET2
goto :START_CONVERT

:RETRY_SET2
echo Download failed, retrying set 2 in 30 seconds...
timeout /t 30 /nobreak >NUL
goto :DOWNLOAD_UUPS2

:START_CONVERT
if EXIST convert-UUP.cmd call convert-UUP.cmd
goto :EOF

:NO_FILE_ERROR
echo We couldn't find one of needed files for this script.
pause
goto :EOF

:DOWNLOAD_CONVERTER_ERROR
echo.
echo An error has occurred while downloading the UUP converter.
pause
goto :EOF

:EOF
